import React, { Component } from 'react';
import Muistiinpanotaulukko from '../components/Muistiinpanotaulukko';


class ListaaMuistiinpanot extends Component {
  render() {
    return (
    <div><Muistiinpanotaulukko /></div>
    );
  }
}

export default ListaaMuistiinpanot;